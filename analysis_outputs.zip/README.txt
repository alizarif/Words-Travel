Words Travel: saved analysis outputs

Produced offline by 02_analysis.ipynb after every retained exhibit and numerical text value passed verification.
results/: all 61 complete result families as CSV files.
output/: numerical source CSVs for the retained manuscript tables.
audit/: newly generated or changed analysis checks, including final_verification.json.
metadata.json: input/source hashes, environment, runtime, and exhibit/result catalogues.
manifest.json: SHA-256 checksums of every other archive member.
Original measurement audits remain in data/scored_data.zip. Figure PDFs are in figures/.
Reproduce from the two notebook sources and the two supplied input archives; no API calls are needed.
